from flask import render_template, url_for, flash, redirect
from flaskblog.forms import RegistrationForm, LoginForm
from flaskblog import app, db, bcrypt
from datetime import datetime
from flaskblog.models import User, Post

posts = [
    {
        'author':'Corey Schafer',
        'title':'Blog Post1',
        'content':'First Blog Post',
        'date_posted':'18, May 2019',
        'last_updated_date':f"{datetime.now()::%d, %b %Y}"
    },
    {
        'author':'Srihari K S S',
        'title':'Blog Post2',
        'content':'Second Blog Post',
        'date_posted':'18, May 2019',
        'last_updated_date':f"{datetime.now()::%d, %b %Y}"
    }
]

@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html', posts=posts)

@app.route("/about")
def about():
    return render_template('about.html', title='About')

@app.route("/register", methods = ['GET','POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(form.username.data, form.email.data, hashed_password)
        db.session.add(user)
        db.session.commit()
        flash(f'Acount has been created for {form.username.data}!', 'success')
        return redirect(url_for('login'))
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'admin@blog.com' and form.password.data == 'password':
            flash('You have been logged in!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check username and pasword.','danger')
    return render_template('login.html', form=form, title = 'Login')
